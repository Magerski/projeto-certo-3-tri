criaCartao(
    'Programação',
    'O que é Python?',
    'O Python é uma linguagem de programação'
)

criaCartao(
    'Geografia',
    'Qual a capital do Paraná?',
    'A capital do Paraná é Curitiba'
)

criaCartao(
    'Futebol',
    'Que time ganhou a Libertadores de 2011?',
    'O time campeão foi o brasileiro Santos'
)

criaCartao(
    'Lingua inglesa',
    'Como se diz oi em Inglês?',
    'Oi em ingles é HI (RAI)'
)
